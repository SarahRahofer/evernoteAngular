import {Component, Input, OnInit} from '@angular/core';
import {Todo} from "../shared/todo";
import {CollectionListItemComponent} from "../collection-list-item/collection-list-item.component";
import {RouterLink} from "@angular/router";
import {EverNoteService} from "../shared/ever-note.service";
import {TodoListItemComponent} from "../todo-list-item/todo-list-item.component";
import {AuthenticationService} from "../shared/authentication.service";

@Component({
  selector: 'en-todo-list',
  standalone: true,
  imports: [
    CollectionListItemComponent,
    TodoListItemComponent,
    RouterLink
  ],
  templateUrl: './todo-list.component.html',
  styles: ``
})
export class TodoListComponent implements OnInit{
  todos: Todo [] = [];
  constructor(private en:EverNoteService,
              protected authService: AuthenticationService){
  }
  ngOnInit(){
    this.en.getAllTodos().subscribe(res=>this.todos=res);
  }
}

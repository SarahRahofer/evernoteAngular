import {Component, OnInit} from '@angular/core';
import {CollectionListItemComponent} from "../collection-list-item/collection-list-item.component";
import {Category} from "../shared/category";
import {EverNoteService} from "../shared/ever-note.service";
import {RouterLink} from "@angular/router";
import {AuthenticationService} from "../shared/authentication.service";
import {Note} from "../shared/note";
import {NoteFactory} from "../shared/note-factory";
import {CategoryFactory} from "../shared/category-factory";
import {ToastrService} from "ngx-toastr";
import {CategoryListItemComponent} from "../category-list-item/category-list-item.component";

@Component({
  selector: 'en-category-list',
  standalone: true,
  imports: [
    CollectionListItemComponent,
    RouterLink,
    CategoryListItemComponent
  ],
  templateUrl: './category-list.component.html',
  styles: ``
})
export class CategoryListComponent implements OnInit{
  categories: Category[]=[];
  category:Category = CategoryFactory.empty();
  constructor(private en:EverNoteService,
              private toastr:ToastrService,
              protected authService: AuthenticationService){
  }
  ngOnInit(){
    this.en.getAllCategories().subscribe(res=>this.categories=res);
  }

}

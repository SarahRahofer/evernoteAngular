import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Collection, Note} from "../shared/collection";
import {Todo} from "../shared/todo";
import {NoteListComponent} from "../note-list/note-list.component";
import {CollectionListItemComponent} from "../collection-list-item/collection-list-item.component";
import {EverNoteService} from "../shared/ever-note.service";
import {RouterLink} from "@angular/router";
import {AuthenticationService} from "../shared/authentication.service";
import {NgClass} from "@angular/common";

@Component({
  selector: 'en-collection-list',
  standalone: true,
  imports: [
    NoteListComponent,
    CollectionListItemComponent,
    RouterLink,
    NgClass
  ],
  templateUrl: './collection-list.component.html',
  styles: ``
})
export class CollectionListComponent implements OnInit{
  collections: Collection[] = [];

  constructor(private en:EverNoteService,
              protected authService: AuthenticationService){
  }
  ngOnInit(){
    this.en.getAllCollections().subscribe(res=>this.collections=res);
  }



}

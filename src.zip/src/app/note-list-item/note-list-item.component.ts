import {Component, Input} from '@angular/core';
import {Note, Todo} from "../shared/note";
import {Collection} from "../shared/collection";

@Component({
  selector: 'a.en-note-list-item',
  standalone: true,
  imports: [],
  templateUrl: './note-list-item.component.html',
  styles: ``
})
export class NoteListItemComponent{
  note: Note | undefined;
}

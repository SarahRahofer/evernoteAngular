import {AfterViewInit, Component, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {TodoFactory} from "../shared/todo-factory";
import {EverNoteService} from "../shared/ever-note.service";
import {ActivatedRoute, Router} from "@angular/router";
import {TodoFormErrorMessages} from "./todo-form-error-messages";
import {Todo} from "../shared/note";

declare let $: any;
@Component({
  selector: 'en-todo-form',
  standalone: true,
    imports: [
        ReactiveFormsModule
    ],
  templateUrl: './todo-form.component.html',
  styles: ``
})
export class TodoFormComponent implements OnInit, AfterViewInit{
  todoForm : FormGroup;
  todo = TodoFactory.empty();
  isUpdatingTodo = false;
  images: FormArray;
  errors: { [key: string]: string } = {};
  categories: any[] = [];
  constructor(
    private fb: FormBuilder,
    private en: EverNoteService,
    private route: ActivatedRoute,
    private router: Router
  ){
    this.todoForm = this.fb.group({});
    this.images = this.fb.array([]);
  }
  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.en.getAllCategories().subscribe(categories => {
      this.categories = categories;
    })
    if(id){
      //Todo wird upgedated
      this.isUpdatingTodo = true;
      this.en.getTodo(id).subscribe(todo=>{
        this.todo = todo;
        this.initTodo();
      });
    }else{
      this.initTodo();
    }
    this.initTodo();
  }

  initTodo(){
    this.buildThumbnailsArray();
    this.todoForm = this.fb.group({
      id: [this.todo.id],
      title: [this.todo.title, Validators.required],
      description: [this.todo.description],
      duedate: [this.todo.duedate, Validators.required],
      note_id: [this.todo.note_id],
      visibility: [this.todo.visibility],
      images: this.images,
      categories: [this.todo.categories ? this.todo.categories.map(category => category.id) : []]
    });console.log(this.todoForm);
    this.todoForm.statusChanges.subscribe(() => this.updateErrorMessages());
  }
buildThumbnailsArray(){
  if (this.todo.images) {
    this.images = this.fb.array([]);
    for (let img of this.todo.images) {
      let fg = this.fb.group({
        id: this.fb.control(img.id),
        url: this.fb.control(img.url, Validators.required),
        title: this.fb.control(img.title, Validators.required)
      });
      this.images.push(fg);
    }
  }
}
  submitForm() {
    this.todoForm.value.images = this.todoForm.value.images.filter((thumbnail:{url:string})=>thumbnail.url);
    const todo: Todo = TodoFactory.fromObject(this.todoForm.value);
    console.log(todo);
    if (this.isUpdatingTodo) {
      this.en.updateTodo(todo).subscribe(() => {
        this.router.navigate(['../'], { relativeTo: this.route });
      });
    } else {
      this.en.createTodo(todo).subscribe(() => {
        this.router.navigate(['../'], { relativeTo: this.route });
      });
    }
  }
private updateErrorMessages() {
  this.errors = {};
  for(const message of TodoFormErrorMessages){
    const control = this.todoForm.get(message.forControl);
  if (control && control.dirty && control.invalid &&
    control.errors && control.errors[message.forValidator]) {
    this.errors[message.forControl] = message.text;
  }
  }
}
addThumbnailControl() {
    this.images.push(this.fb.group({ id: 0, url: null, title: null }));
  }
  ngAfterViewInit(): void {
    $(document).ready(function() {
      $('.ui.toggle.checkbox').checkbox();
    });}

}

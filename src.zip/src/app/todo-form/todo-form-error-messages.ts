export class ErrorMessages {
  constructor(
    public forControl: string,
    public forValidator: string,
    public text: string
  ) { }
}
export const TodoFormErrorMessages =[
  new ErrorMessages('title', 'required', 'Geben Sie einen Titel ein!'),
  new ErrorMessages('duedate', 'required', 'Geben Sie ein Fälligkeitsdatum ein!')
];

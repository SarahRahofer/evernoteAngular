import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router, RouterLink} from "@angular/router";
import {Todo} from "../shared/todo";
import {EverNoteService} from "../shared/ever-note.service";
import {Note} from "../shared/note";
import {TodoFactory} from "../shared/todo-factory";
import {ToastrService} from "ngx-toastr";
import {AuthenticationService} from "../shared/authentication.service";

@Component({
  selector: 'en-todo-details',
  standalone: true,
  imports: [
    RouterLink
  ],
  templateUrl: './todo-details.component.html',
  styles: ``
})
export class TodoDetailsComponent implements OnInit{
  todo:Todo = TodoFactory.empty();
  constructor(private en:EverNoteService,
              private route:ActivatedRoute,
              private router:Router,
              private toastr:ToastrService,
              protected authService: AuthenticationService) {
  }
  ngOnInit(): void {
    const params = this.route.snapshot.params;
    this.en.getTodo(params['id']).subscribe((t:Todo)=>this.todo=t);
  }

  removeTodo() {
    if(confirm("Todo wirklich löschen?")){
      this.en.removeTodo(this.todo.id).subscribe(
        ()=> {
          this.router.navigate(['../', {relativeTo: this.route}])
          this.toastr.success('Todo gelöscht!');
        })
    }
  }
}

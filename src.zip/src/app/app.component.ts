import { Component } from '@angular/core';
import {RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {CollectionListComponent} from "./collection-list/collection-list.component";
import {Collection, Note} from "./shared/collection";
import {NoteListComponent} from "./note-list/note-list.component";
import {NoteDetailsComponent} from "./note-details/note-details.component";
import {Category} from "./shared/category";
import {AuthenticationService} from "./shared/authentication.service";

@Component({
  selector: 'en-root',
  standalone: true,
  imports: [RouterOutlet, CollectionListComponent, NoteListComponent, NoteDetailsComponent, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html'
})
export class AppComponent {
  constructor(private authService: AuthenticationService) {
  }
  isLoggedIn(){
    return this.authService.isLoggedIn();
  }

  getLoginLabel(){
    return this.isLoggedIn() ? "Logout" : "Login";
  }


}

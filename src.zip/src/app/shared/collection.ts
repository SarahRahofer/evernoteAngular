import {Note} from "./note";
export {Note} from "./note";
export class Collection {
  constructor(public id:number,
              public title:string,
              public visibility:boolean,
              public user_id: number,
              public notes?: Note[]) {
  }
}

import { Injectable } from '@angular/core';
import {Collection, Note} from "./collection";
import {Category, Todo} from "./todo";
import {HttpClient} from "@angular/common/http";
import {catchError, Observable, retry, throwError} from "rxjs";
import {User} from "./user";

@Injectable({
  providedIn: 'root'
})
export class EverNoteService {
  private api = 'http://kwmevernote.s2010456024.student.kwmhgb.at/api';
  constructor(private http:HttpClient) {
  }
  //Holt alle Collections vom Server
  getAllCollections():Observable<Array<Collection>>{
    return this.http.get<Array<Collection>>(`${this.api}/collections`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  //Hollt einzelne Collection zurück
  getAllNotes(id:number):Observable<Collection>{
    return this.http.get<Collection>(`${this.api}/collections/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  getNote(id:number):Observable<Note> {
    return this.http.get<Note>(`${this.api}/collections/notes/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  getCategory(id:number):Observable<Category> {
    return this.http.get<Category>(`${this.api}/tags/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  //Holt alle Tags
  getAllCategories():Observable<Array<Category>>{
    return this.http.get<Array<Category>>(`${this.api}/tags`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  //Holt alle Todos
  getAllTodos():Observable<Array<Todo>>{
    return this.http.get<Array<Todo>>(`${this.api}/todos`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  getTodo(id:number):Observable<Todo>{
    return this.http.get<Todo>(`${this.api}/todos/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  getCollection(id:number):Observable<Collection> {
    return this.http.get<Collection>(`${this.api}/collections/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  //Löschfunktionen
  removeNote(id:number):Observable<any>{
    return this.http.delete<Note>(`${this.api}/collections/notes/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  removeCategory(id:number):Observable<any>{
    return this.http.delete<Category>(`${this.api}/tags/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  removeCollection(id:number):Observable<any>{
    return this.http.delete<Collection>(`${this.api}/collections/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  removeTodo(id:number):Observable<any>{
    return this.http.delete<Todo>(`${this.api}/todos/${id}`)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  private errorHandler(error:Error | any):Observable<any>{
    return throwError(error);
  };
  //Createfunktionen
  createCollection(collection:Collection):Observable<any>{
    return this.http.post(`${this.api}/collections`,collection)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  createNote(note:Note, collection_id:number):Observable<any>{
    return this.http.post(`${this.api}/collections/${collection_id}`,note)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  updateNote(note:Note):Observable<any>{
    return this.http.put(`${this.api}/collections/notes/${note.id}`,note)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }

  createTodo(todo:Todo):Observable<any>{
    return this.http.post(`${this.api}/todos`,todo)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  updateTodo(todo:Todo):Observable<any>{
    return this.http.put(`${this.api}/todos/${todo.id}`,todo)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  createCategory(category:Category):Observable<any>{
    return this.http.post(`${this.api}/tags`,category)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
  updateCategory(category:Category):Observable<any>{
    return this.http.put(`${this.api}/tags/${category.id}`,category)
      .pipe(retry(3)).pipe(catchError(this.errorHandler));
  }
}

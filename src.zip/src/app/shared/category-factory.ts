import {Category, Note} from "./note";

export class CategoryFactory {
  static empty():Category{
    return new Category(0, '')
  }
  static fromObject(rawCategory: any):Category{
    return new Category(rawCategory.id, rawCategory.name);
  }
}

import {Note, Image} from "./note";

export class NoteFactory {
  static empty():Note{
    return new Note(0, '', '', 0,[], [new Image(0, '', '')], [])
  }
  static fromObject(rawNote: any):Note{
    return new Note(
      rawNote.id,
      rawNote.title,
      rawNote.description,
      rawNote.collection_id,
      rawNote.todos,
      rawNote.images,
      rawNote.categories
    );
  }
}

import {Collection} from "./collection";

export class CollectionFactory {
  static empty():Collection{
    return new Collection(0, '', false, 0, [])
  }
  static fromObject(rawCollection: any):Collection{
    return new Collection(
      rawCollection.id, rawCollection.title, rawCollection.visibility, rawCollection.user_id ,rawCollection.notes
    );
  }
}

import {Image, Todo} from "./todo";

export class TodoFactory {
  static empty():Todo{
    return new Todo(0, '', '', new Date(),0, false, [new Image(0, '', '')], [])
  }
  static fromObject(rawTodo: any):Todo{
    console.log(rawTodo);
    return new Todo(
      rawTodo.id, rawTodo.title, rawTodo.description,
      typeof(rawTodo.duedate) === 'string' ? new Date(rawTodo.duedate) : rawTodo.duedate, rawTodo.note_id,
      rawTodo.visibility, rawTodo.images, rawTodo.categories
    );
  }
}

import {Image} from "./image";
export {Image} from "./image";
import {Todo} from "./todo";
export {Todo} from "./todo";
import {Category} from "./category";
export {Category} from "./category";
export class Note {
  constructor(public id:number,
             public title:string,
             public description:string,
              public collection_id: number,
              public todos?: Todo[],
             public images?: Image[],
             public categories?: Category[]){}
}

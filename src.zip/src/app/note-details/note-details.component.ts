import {Component, OnInit} from '@angular/core';
import {Note} from "../shared/note";
import {EverNoteService} from "../shared/ever-note.service";
import {ActivatedRoute, Router, RouterLink, RouterLinkActive} from "@angular/router";
import {Collection} from "../shared/collection";
import {DatePipe} from "@angular/common";
import {CollectionFactory} from "../shared/collection-factory";
import {NoteFactory} from "../shared/note-factory";
import {ToastrService} from "ngx-toastr";
import {AuthenticationService} from "../shared/authentication.service";

@Component({
  selector: 'en-note-details',
  standalone: true,
  imports: [
    RouterLink,
    RouterLinkActive,
    DatePipe
  ],
  templateUrl: './note-details.component.html',
  styles: ``
})
export class NoteDetailsComponent implements OnInit{
  collection: Collection = CollectionFactory.empty();
  note:Note = NoteFactory.empty();
  constructor(private en:EverNoteService,
              private route:ActivatedRoute,
              private router:Router,
              private toastr:ToastrService,
              protected authService: AuthenticationService) {
  }
  ngOnInit(): void {
    const params = this.route.snapshot.params;
    this.en.getNote(params['id']).subscribe((n:Note)=>{
      this.note=n
      this.loadCollection(n.collection_id);//von ChatGPT
      console.log(this.note)
    });
  }
  //Notiz löschen
  removeNote() {
    if(confirm("Notiz wirklich löschen?")){
      this.en.removeNote(this.note.id).subscribe(
        ()=> {
          this.router.navigate(['./collections/', this.note.collection_id]),
            this.toastr.success('Notiz gelöscht!');
        });
    }
  }

  //von ChatGPT - lädt Listen basierend auf der ID
  loadCollection(id: number): void {
    this.en.getCollection(id).subscribe((c: Collection) => this.collection = c);
  }

}

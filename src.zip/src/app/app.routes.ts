import { Routes } from '@angular/router';
import {CollectionListComponent} from "./collection-list/collection-list.component";
import {NoteListComponent} from "./note-list/note-list.component";
import {NoteDetailsComponent} from "./note-details/note-details.component";
import {TodoListComponent} from "./todo-list/todo-list.component";
import {TodoDetailsComponent} from "./todo-details/todo-details.component";
import {CollectionFormComponent} from "./collection-form/collection-form.component";
import {NoteFormComponent} from "./note-form/note-form.component";
import {CategoryListComponent} from "./category-list/category-list.component";
import {LoginComponent} from "./login/login.component";
import {canNavigateToAdminGuard} from "./can-navigate-to-admin.guard";
import {TodoFormComponent} from "./todo-form/todo-form.component";
import {CategoryFormComponent} from "./category-form/category-form.component";

export const routes: Routes = [
  {path:'', redirectTo:'collections', pathMatch: 'full'},
  {path:'collections', component: CollectionListComponent},
  {path:'collections/admin', component: CollectionFormComponent, canActivate:[canNavigateToAdminGuard]},
  {path:'tags', component: CategoryListComponent},
  {path:'tags/admin', component: CategoryFormComponent, canActivate:[canNavigateToAdminGuard]},
  {path:'tags/admin/:id', component: CategoryFormComponent, canActivate:[canNavigateToAdminGuard]},
  {path:'todos', component: TodoListComponent},
  {path:'todos/admin', component: TodoFormComponent, canActivate:[canNavigateToAdminGuard]},
  {path:'todos/admin/:id', component: TodoFormComponent, canActivate:[canNavigateToAdminGuard]},
  {path:'todos/:id', component: TodoDetailsComponent},
  {path:'collections/:id', component: NoteListComponent},
  {path:'collections/note/admin/:collection_id', component: NoteFormComponent, canActivate:[canNavigateToAdminGuard]},
  {path:'collections/notes/admin/:id', component: NoteFormComponent, canActivate:[canNavigateToAdminGuard]},
  {path:'collections/notes/:id', component: NoteDetailsComponent},
  {path:'login',component:LoginComponent}
];


export class ErrorMessage{
  constructor(
    public forControl: string,
    public forValidator: string,
    public text: string
  ) { }
}
export const NoteFormErrorMessages =
  new ErrorMessage('title', 'required', 'Geben Sie einen Titel ein!');

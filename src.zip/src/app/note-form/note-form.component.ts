import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { NoteFactory } from "../shared/note-factory";
import { EverNoteService } from "../shared/ever-note.service";
import { ActivatedRoute, Router } from "@angular/router";
import { Category } from "../shared/category";
import { Note } from "../shared/note";
import {NoteFormErrorMessages} from "./note-form-error-messages";
import {catchError} from "rxjs";

declare var $: any;

@Component({
  selector: 'en-note-form',
  standalone: true,
  imports: [
    ReactiveFormsModule
  ],
  templateUrl: './note-form.component.html',
  styles: ``
})
export class NoteFormComponent implements OnInit, AfterViewInit {
  noteForm: FormGroup;
  note = NoteFactory.empty();
  categories: any[] = [];
  isUpdatingNote = false;
  images: FormArray;
  errors: { [key: string]: string } = {};
  constructor(
    private fb: FormBuilder,
    private en: EverNoteService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.noteForm = this.fb.group({}); //leere Gruppe wird angelegt
    this.images = this.fb.array([]);
  }

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.en.getAllCategories().subscribe(categories => {
      this.categories = categories;
    })

    if (id) {
      // Notiz updaten
      this.isUpdatingNote = true;
      this.en.getNote(id).subscribe(note => {
        this.note = note;
        this.initNote();
      });
    }else {
      this.note.collection_id = this.route.snapshot.params['collection_id'];
      this.initNote();
    }
    this.initNote();
  }

  initNote() {
    this.buildThumbnailsArray();
    //FormGroup noteForm wird überschrieben
    this.noteForm = this.fb.group({
      id: [this.note.id],
      title: [this.note.title, Validators.required],
      description: [this.note.description],
      collection_id: [this.note.collection_id],
      images: this.images,
      categories: [this.note.categories ? this.note.categories.map(category => category.id) : []]
    });
    this.noteForm.statusChanges.subscribe(() => this.updateErrorMessages());
  }

  buildThumbnailsArray() {
    if (this.note.images) {
      this.images = this.fb.array([]);
      for (let img of this.note.images) {
        let fg = this.fb.group({
          id: this.fb.control(img.id),
          url: this.fb.control(img.url, Validators.required),
          title: this.fb.control(img.title, Validators.required)
        });
        this.images.push(fg);
      }
    }
  }

  addThumbnailControl() {
    this.images.push(this.fb.group({ id: 0, url: null, title: null }));
  }

  submitForm() {
    this.noteForm.value.images = this.noteForm.value.images.filter((thumbnail:{url:string})=>thumbnail.url);
    const note: Note = NoteFactory.fromObject(this.noteForm.value);
    if (this.isUpdatingNote) {
      this.en.updateNote(note).subscribe(() => {
        this.router.navigate(['../../', note.id], { relativeTo: this.route });
      });
    } else {
      this.en.createNote(note, note.collection_id).subscribe(() => {
        this.router.navigate(['../../../', note.collection_id], { relativeTo: this.route });
      });
    }
  }

  ngAfterViewInit(): void {
    // jQuery-Initialisierung für Semantic UI Dropdown
    $(document).ready(function () {
      $('#multiselect').dropdown();
    });
  }

  private updateErrorMessages() {
    this.errors = {};
    const control = this.noteForm.get(NoteFormErrorMessages.forControl);
    if (control && control.dirty && control.invalid &&
      control.errors && control.errors[NoteFormErrorMessages.forValidator]) {
      this.errors[NoteFormErrorMessages.forControl] = NoteFormErrorMessages.text;
    }
  }
}

import {Component, Input} from '@angular/core';
import {Category} from "../shared/category";
import {CategoryFactory} from "../shared/category-factory";
import {EverNoteService} from "../shared/ever-note.service";
import {ToastrService} from "ngx-toastr";
import {ActivatedRoute, Router, RouterLink} from "@angular/router";
import {AuthenticationService} from "../shared/authentication.service";

@Component({
  selector: 'div.en-category-list-item',
  standalone: true,
  imports: [
    RouterLink
  ],
  templateUrl: './category-list-item.component.html'
})
export class CategoryListItemComponent {
  @Input() category:Category = CategoryFactory.empty();
  constructor(
    private en:EverNoteService,
    private toastr:ToastrService,
    private route:ActivatedRoute,
    private router: Router,
    protected authService: AuthenticationService
  ) {
  }
  removeCategory() {
    if(confirm("Tag wirklich löschen?")){
      this.en.removeCategory(this.category.id).subscribe(
        ()=> {
          this.toastr.success('Tag gelöscht!');
        });
    }
  }
}

import {AfterViewInit, Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {Collection} from "../shared/collection";
import {CollectionFactory} from "../shared/collection-factory";
import {EverNoteService} from "../shared/ever-note.service";
import {ActivatedRoute, Router} from "@angular/router";
import {CollectionFormErrorMessages} from "./collection-form-error-messages";
import {AuthenticationService} from "../shared/authentication.service";
declare let $: any;
@Component({
  selector: 'en-collection-form',
  standalone: true,
  imports: [
    ReactiveFormsModule
  ],
  templateUrl: './collection-form.component.html',
  styles: ``
})
export class CollectionFormComponent implements OnInit, AfterViewInit{
  collectionForm : FormGroup;
  collection = CollectionFactory.empty();
  isUpdatingCollection = false;
  errors:{[key:string]:string} = {};

  constructor(private fb: FormBuilder,
              private en : EverNoteService,
              private route : ActivatedRoute,
              private router:Router,
              private authService: AuthenticationService) {
    this.collectionForm = this.fb.group({});
  }
  initCollection(){
    this.collectionForm = this.fb.group({
      id: this.collection.id,
      title: [this.collection.title, Validators.required],
      visibility: this.collection.visibility
    });
    this.collectionForm.statusChanges.subscribe(()=>this.updateErrorMessages());
  }

  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    if(id){
      // updaten
      this.isUpdatingCollection = true;
    }
    this.initCollection();
  }

  ngAfterViewInit(): void {
    $(document).ready(function() {
      $('.ui.toggle.checkbox').checkbox();
      $('#multiselect').dropdown();
    });
  }

  submitForm() {
      const collection: Collection = CollectionFactory.fromObject(this.collectionForm.value);

      const currentUser = this.authService.getCurrentUser();
    if(currentUser){
      collection.user_id = currentUser.id;
    }
      this.en.createCollection(collection).subscribe(() => {
        this.collection = CollectionFactory.empty();
        this.collectionForm.reset(CollectionFactory.empty());
        this.router.navigate(['../'], {relativeTo: this.route})
      });
  }

  private updateErrorMessages() {
    this.errors = {};
    const control = this.collectionForm.get(CollectionFormErrorMessages.forControl);
    if(control && control.dirty && control.invalid &&
    control.errors && control.errors[CollectionFormErrorMessages.forValidator]){
      this.errors[CollectionFormErrorMessages.forControl] = CollectionFormErrorMessages.text;
    }
  }
}

import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {EverNoteService} from "../shared/ever-note.service";
import {ActivatedRoute, Router} from "@angular/router";
import {AuthenticationService} from "../shared/authentication.service";
import {CategoryFactory} from "../shared/category-factory";
import {Category} from "../shared/category";
import {CategoryFormErrorMessages} from "./category-form-error-messages";

@Component({
  selector: 'en-category-form',
  standalone: true,
    imports: [
        ReactiveFormsModule
    ],
  templateUrl: './category-form.component.html',
  styles: ``
})
export class CategoryFormComponent implements OnInit{
  categoryForm : FormGroup;
  category = CategoryFactory.empty();
  isUpdatingCategory = false;
  errors:{[key:string]:string} = {};

  constructor(private fb: FormBuilder,
              private en : EverNoteService,
              private route : ActivatedRoute,
              private router:Router) {
    this.categoryForm = this.fb.group({});
  }
  initCategory(){
    this.categoryForm = this.fb.group({
      id: this.category.id,
      name: [this.category.name, Validators.required]
    });
    this.categoryForm.statusChanges.subscribe(()=>this.updateErrorMessages());
  }
  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    if(id){
      this.isUpdatingCategory = true;
      this.en.getCategory(id).subscribe(category => {
        this.category = category;
        this.initCategory();
      });
    }
    this.initCategory();
  }
  submitForm() {
    const category: Category = CategoryFactory.fromObject(this.categoryForm.value);
    console.log(category);
    this.en.createCategory(category).subscribe(() => {
      this.category = CategoryFactory.empty();
      this.categoryForm.reset(CategoryFactory.empty());
      this.router.navigate(['../'], {relativeTo: this.route})
    });
  }

  private updateErrorMessages() {
    this.errors = {};
    const control = this.categoryForm.get(CategoryFormErrorMessages.forControl);
    if(control && control.dirty && control.invalid &&
      control.errors && control.errors[CategoryFormErrorMessages.forValidator]){
      this.errors[CategoryFormErrorMessages.forControl] = CategoryFormErrorMessages.text;
    }
  }
}

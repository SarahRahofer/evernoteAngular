export class ErrorMessage{
  constructor(
    public forControl: string,
    public forValidator: string,
    public text: string){}
}
export const CategoryFormErrorMessages =
  new ErrorMessage('name', 'required', 'Geben Sie einen Titel ein!');


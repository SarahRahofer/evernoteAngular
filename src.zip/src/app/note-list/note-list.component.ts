import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Collection, Note} from "../shared/collection";
import {CollectionListItemComponent} from "../collection-list-item/collection-list-item.component";
import {Todo} from "../shared/todo";
import {NoteListItemComponent} from "../note-list-item/note-list-item.component";
import {ActivatedRoute, Router, RouterLink, RouterLinkActive} from "@angular/router";
import {EverNoteService} from "../shared/ever-note.service";
import {CollectionFactory} from "../shared/collection-factory";
import {ToastrService} from "ngx-toastr";
import {AuthenticationService} from "../shared/authentication.service";

@Component({
  selector: 'en-note-list',
  standalone: true,
  imports: [
    CollectionListItemComponent,
    NoteListItemComponent,
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './note-list.component.html',
  styles: ``
})
export class NoteListComponent implements OnInit{
  collection:Collection = CollectionFactory.empty();
  notes: Note[] = [];
  constructor(private en:EverNoteService,
              private route:ActivatedRoute,
              private router:Router,
              private toastr:ToastrService,
              protected authService: AuthenticationService) {
  }
  ngOnInit(){
    const params = this.route.snapshot.params;
    this.en.getAllNotes(params['id']).subscribe((c:Collection)=>this.collection=c);
  }

  removeCollection() {
    if(confirm("Liste wirklich löschen?")){
      this.en.removeCollection(this.collection.id).subscribe(
        ()=>{this.router.navigate(['../', {relativeTo:this.route}])
        this.toastr.success('Liste gelöscht!');
        }
      );
    }
  }
}



